package Lesson_2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.AfterAll;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.BeforeStep;

public class wiki_hook {

	// Global hooks
	// Global hooks will run once before any scenario is run or after all scenario
	// have been run.

	@BeforeAll
	public static void featureStarts() {

		System.out.println("The feature has started execution11111111111111111111111");
	}

	@AfterAll
	public static void featureEnds() {

		System.out.println("The feature has completed execution111111111111111111111111111");
	}

	public static WebDriver driver;

	@Before(order = 0, value = "@login and @functional")
	public void ConditionalHooks() {

		System.out.println("Task 1: Open the browser222222222222222222222222222");
	}

	@Before(order = 0, value = "@functional")
	public void openBrowser() {

		System.out.println("Task 2: Initialize the browser and open it2222222222222222222");
		System.out.println("Opening Browser22222222222222222");
		driver = new ChromeDriver();

	}

	@Before(order = 1, value = "@functional")
	public void managebrowserWindow() {

		System.out.println("Task 3: Delete the cookies and maximize window22222222222");

		// driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
	}

	@Before(order = 2, value = "@functional")
	public void openUrl() {

		System.out.println("Task 4: Open the URL in browser2222222222222");

		driver.get("https://en.wikipedia.org/w/index.php?title=Special:CreateAccount&returnto=Wikipedia%3ASign+up");
	}

	@BeforeStep
	public void stepStart() {

		System.out.println("The steps has started excution3333333333333");
	}

	@AfterStep
	public void stepEnd() {

		System.out.println("The steps has completed execution33333333");
	}

	// these method I want to run after every scenario in my feature

	@After(order = 2, value = "@functional")
	public void captureTitle() {

		System.out.println(driver.getTitle());

	}

	@After(order = 1, value = "@functional")
	public void closeBrowser() {

		// driver.close();
		driver.quit();
	}

	@After(order = 0, value = "@functional")
	public void TestCompleteMessage() {

		System.out.println("Test scenario is now completed4444444444444444444");
	}

}