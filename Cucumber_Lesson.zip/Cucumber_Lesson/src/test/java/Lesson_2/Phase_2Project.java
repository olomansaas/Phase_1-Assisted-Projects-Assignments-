package Lesson_2;

import java.time.Duration;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Phase_2Project {
	
	WebDriver driver;
	
	@Given("I open the Chrome browser and enter Amazon URL")
	public void i_open_the_chrome_browser_and_enter_amazon_url() throws InterruptedException {
		
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		// Navigate to Amazon Home_page
		driver.get("https://amazon.in/");
		Thread.sleep(5000);
	}

	
	  @When("User navigated to login button")
	  public void user_navigated_to_login_button()
	  { WebElement signInButton = driver.findElement(By.id("nav-link-accountList")); signInButton.click(); }
	  
	  @When("Enter valid Username") public void enter_valid_username() 
	  { WebElement emailInput = driver.findElement(By.id("ap_email"));
	  emailInput.sendKeys("Your_Username"); }
	  
	  @When("Enter valid Password") 
	  public void enter_valid_password() {
	  
	  WebElement continueButton = driver.findElement(By.id("continue"));
	  continueButton.click();
	  WebElement passwordInput = driver.findElement(By.id("ap_password"));
	  passwordInput.sendKeys("Your_Password"); }
	  
	  @When("Clicked on login button")
	  public void clicked_on_login_button() throws InterruptedException { 
		  WebElement signInSubmitButton = driver.findElement(By.id("signInSubmit")); 
		  signInSubmitButton.click(); 
	
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10)); }
	 

	@Then("Search for a product")
	public void search_for_a_product() {
		WebElement searchBox = driver.findElement(By.id("twotabsearchtextbox"));
		searchBox.sendKeys("iPhone 13");
		WebElement searchButton = driver.findElement(By.id("nav-search-submit-button"));
		searchButton.click();
	}

	@Then("Applied Filters")
	public void applied_filters() {
		WebElement filterElement1 = driver.findElement(By.xpath("//*[@id=\"p_n_feature_twenty-nine_browse-bin/81332994031\"]/span/a/span"));
		filterElement1.click();

		WebElement filterElement2 = driver.findElement(By.xpath("//*[@id=\"p_n_feature_nine_browse-bin/8561127031\"]/span/a/span"));
		filterElement2.click();
	}

	@Then("Searched for a specific product")
	public void searched_for_a_specific_product() throws InterruptedException {
		WebElement productElement = driver.findElement(By.xpath("//*[@id=\"search\"]/div[1]/div[1]/div/span[1]/div[1]/div[2]/div/div/div/div/div/div[2]/div/div/div[1]/h2/a/span"));
		productElement.click();

		Thread.sleep(5000);
	}

	@Then("Switched the Browser Tab")
	public void switched_the_browser_tab() {
		
		ArrayList tabs = new ArrayList(driver.getWindowHandles());
		driver.switchTo().window((String) tabs.get(1));
	}

	@Then("Close the browser")
	public void close_the_browser() {
		driver.close();
	}


}
