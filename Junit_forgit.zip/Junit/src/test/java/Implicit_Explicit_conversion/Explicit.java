package Implicit_Explicit_conversion;

public class Explicit {

}
