package Junit_Demo;

import org.junit.jupiter.api.Test;

public class TestAnnotation {
	
	@Test
	public void Method1() {
		System.out.println("Junit First");
		
	}

}
