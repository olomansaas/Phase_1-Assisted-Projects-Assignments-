package Project;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class GoogleSearchTest {
	
 private WebDriver driver;
 
 @BeforeEach
 public void setUp() {
 // Initialize WebDriver
 driver = new ChromeDriver();
 }
 
 
 @Test
 public void testGoogleSearch() throws InterruptedException {
 // Navigate to Google
 driver.get("http://www.google.com");
 driver.manage().window().maximize();
 WebElement searchBox = driver.findElement(By.name("q"));
 Thread.sleep(2000);
 searchBox.sendKeys("java");
 // Submit the search
 Thread.sleep(2000);
 searchBox.submit();
 
 Thread.sleep(10000);
 WebElement link = driver.findElement(By.xpath("//h3[contains(text(),'Java | Oracle')]"));
 link.click();
 
 }
@AfterEach
 public void tearDown() throws InterruptedException {
 // Close the browser
Thread.sleep(5000);
 driver.close();
 } 
}