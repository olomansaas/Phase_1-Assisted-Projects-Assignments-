package Project;

import java.time.Duration;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Facebook {
	private WebDriver driver;

	@BeforeEach
	public void setUp() {

		// Globally Initializing WebDriver
		driver = new ChromeDriver();
	}

	@Test
	public void testFacebookLogin() throws InterruptedException {
		// Open Face-Book
		driver.get("https://www.facebook.com");

		// Find the email input field and enter the test email address
		WebElement emailField = driver.findElement(By.id("email"));
		emailField.sendKeys("ForProjectPurpose1@gmail.com");

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		// Find the password input field and enter the test password
		WebElement passwordField = driver.findElement(By.id("pass"));
		passwordField.sendKeys("ForProjectPurpose");

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		// Find the login button and click it
		WebElement loginButton = driver.findElement(By.name("login"));
		loginButton.click();

		// Wait for navigation and page load
		new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.titleContains("Facebook"));

	}

	@AfterEach
	public void tearDown() {
		// Close the browser
		driver.close();

	}
}